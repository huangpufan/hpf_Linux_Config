---@meta 
 ---@class ffi.namespace*. 
 local m = {}
function m.test() end

